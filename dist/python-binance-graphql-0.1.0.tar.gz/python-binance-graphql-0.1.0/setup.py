# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['python_binance_graphql',
 'python_binance_graphql.models',
 'python_binance_graphql.utils']

package_data = \
{'': ['*']}

install_requires = \
['dataclasses_json>=0.5.4,<0.6.0', 'strawberry-graphql>=0.70.1,<0.71.0']

setup_kwargs = {
    'name': 'python-binance-graphql',
    'version': '0.1.0',
    'description': '',
    'long_description': '# python-binance-graphql\nGraphQL Wrapper over Binance API\n',
    'author': 'Michal Čech',
    'author_email': 'michal.cechy@seznam.cz',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/michal-cech/python-binance-graphql',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
